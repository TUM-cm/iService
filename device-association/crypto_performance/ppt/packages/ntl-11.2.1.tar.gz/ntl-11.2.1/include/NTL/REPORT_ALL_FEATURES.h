
#ifdef NTL_HAVE_ALIGNED_ARRAY
   std::cerr << "NTL_HAVE_ALIGNED_ARRAY\n";
#endif

#ifdef NTL_HAVE_BUILTIN_CLZL
   std::cerr << "NTL_HAVE_BUILTIN_CLZL\n";
#endif

#ifdef NTL_HAVE_LL_TYPE
   std::cerr << "NTL_HAVE_LL_TYPE\n";
#endif

#ifdef NTL_HAVE_SSSE3
   std::cerr << "NTL_HAVE_SSSE3\n";
#endif

#ifdef NTL_HAVE_AVX
   std::cerr << "NTL_HAVE_AVX\n";
#endif

#ifdef NTL_HAVE_PCLMUL
   std::cerr << "NTL_HAVE_PCLMUL\n";
#endif

#ifdef NTL_HAVE_AVX2
   std::cerr << "NTL_HAVE_AVX2\n";
#endif

#ifdef NTL_HAVE_FMA
   std::cerr << "NTL_HAVE_FMA\n";
#endif

#ifdef NTL_HAVE_COPY_TRAITS1
   std::cerr << "NTL_HAVE_COPY_TRAITS1\n";
#endif

#ifdef NTL_HAVE_COPY_TRAITS2
   std::cerr << "NTL_HAVE_COPY_TRAITS2\n";
#endif

#ifdef NTL_HAVE_CHRONO_TIME
   std::cerr << "NTL_HAVE_CHRONO_TIME\n";
#endif

#ifdef NTL_HAVE_MACOS_TIME
   std::cerr << "NTL_HAVE_MACOS_TIME\n";
#endif

#ifdef NTL_HAVE_POSIX_TIME
   std::cerr << "NTL_HAVE_POSIX_TIME\n";
#endif

