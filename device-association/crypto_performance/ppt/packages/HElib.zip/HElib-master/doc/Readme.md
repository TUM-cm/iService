An empty stub for documentation
